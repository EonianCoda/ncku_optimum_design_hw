import argparse
import os
from tqdm import tqdm
import torch
import torch.nn as nn
from torch.utils.tensorboard import SummaryWriter

from sklearn.metrics import recall_score, precision_score, f1_score, accuracy_score
from models.resent import ResNet50
from dataloader import get_dataloader
from optimizers.optimizer import get_optimizer
from utils import get_timestamp, convert_to_scientific

LOGS = './logs'
SAVED_MODEL = './saved_model'


def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--dataset', '--data', default='cifar10')
    parser.add_argument('--epochs', type=float, default=1e-3)
    parser.add_argument('--lr', '--learning_rate', '--learning-rate', type=float, default=1e-3)
    parser.add_argument('--bs', '--batch_size', '--batch-size', type=int, default=1024)
    parser.add_argument('--opt', '--optimizer', default='adam')
    parser.add_argument('--extra', default='')
    args = parser.parse_args()
    return args

if __name__ == '__main__':
    args = get_args()
    dataset = args.dataset
    num_epochs = args.epochs
    learning_rate = args.lr
    batch_size = args.bs
    opt_name = args.optimizer
    extra_exp_name = args.extra

    train_loader, test_loader, num_classes = get_dataloader(dataset, batch_size)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = ResNet50(num_classes = num_classes)
    model = model.to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = get_optimizer(model, opt_name, lr=learning_rate)

    
    timestamp = get_timestamp()
    exp_name = '{}_{}{}_bs{}_epoch{}'.format(timestamp, 
                                opt_name, 
                                convert_to_scientific(learning_rate, 'lr'),
                                batch_size,
                                num_epochs)
    if extra_exp_name != '':
        exp_name = exp_name + f'_{extra_exp_name}'
    log_saving_folder = os.path.join(LOGS, exp_name)
    model_saving_folder = os.path.join(SAVED_MODEL, exp_name)
    os.makedirs(log_saving_folder, exist_ok=True)
    os.makedirs(model_saving_folder, exist_ok=True)
    writer = SummaryWriter(log_dir=log_saving_folder)
    
    
    total_training_steps = len(train_loader)
    total_testing_step = len(test_loader)
    for epoch in range(num_epochs):
        loss_history = []
        num_data = 0
        total_recall = 0.0
        total_precision = 0.0
        total_f1_score = 0.0
        total_accuracy = 0.0
        
        model.train()
        # Training
        for i, (images, labels) in tqdm(enumerate(train_loader), desc=f"Training Epoch {epoch+1}/{num_epochs}", unit="step"):
            images = images.to(device)
            labels = labels.to(device)

            outputs = model(images)
            loss = criterion(outputs, labels)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            
            _, predictions = torch.max(outputs.data, 1)
            
            num_data += labels.size(0)
            recall = recall_score(labels, predictions)
            precision = precision_score(labels, predictions)
            f1 = f1_score(labels, predictions)
            accuracy = f1_score(labels, predictions)
            loss_history.append(float(loss.item()))
            
        
            total_recall += recall
            total_precision += precision
            total_f1_score += f1
            total_accuracy = accuracy    
            tqdm.set_postfix(loss=loss.item(), 
                             recall=recall, 
                             precision=precision, 
                             f1=f1, 
                             accuracy=accuracy)
            tqdm.update()
        
        avg_loss = sum(loss_history) / len(loss_history)
        avg_recall = total_recall / total_training_steps
        avg_precision = total_precision / total_training_steps
        avg_f1_score = total_f1_score / total_training_steps
        avg_accuracy = total_precision / total_training_steps
        writer.add_scalar('Train/loss', avg_loss, epoch)
        writer.add_scalar('Train/recall', avg_recall, epoch)
        writer.add_scalar('Train/precision', avg_precision , epoch)
        writer.add_scalar('Train/accuracy', avg_accuracy, epoch)
        writer.add_scalar('Train/f1_score', avg_f1_score, epoch)
        
        model.eval()
        num_data = 0
        total_recall = 0.0
        total_precision = 0.0
        total_f1_score = 0.0
        total_accuracy = 0.0
        with torch.no_grad():
            for images, labels in tqdm(test_loader, desc=f"Validation Epoch {epoch+1}/{num_epochs}", unit="step"):
                images = images.to(device)
                labels = labels.to(device)

                outputs = model(images)
                _, predicted = torch.max(outputs.data, 1)
                
                num_data += labels.size(0)
                recall = recall_score(labels, predictions)
                precision = precision_score(labels, predictions)
                f1 = f1_score(labels, predictions)
                accuracy = f1_score(labels, predictions)
                loss_history.append(float(loss.item()))
            
                total_recall += recall
                total_precision += precision
                total_f1_score += f1
                total_accuracy = accuracy    
                
                tqdm.set_postfix(loss=loss.item(), 
                                recall=recall, 
                                precision=precision, 
                                f1=f1, 
                                accuracy=accuracy)
                tqdm.update()
            
        avg_recall = total_recall / total_training_steps
        avg_precision = total_precision / total_training_steps
        avg_f1_score = total_f1_score / total_training_steps
        avg_accuracy = total_precision / total_training_steps
        writer.add_scalar('Validation/recall', avg_recall, epoch)
        writer.add_scalar('Validation/precision', avg_precision , epoch)
        writer.add_scalar('Validation/accuracy', avg_accuracy, epoch)
        writer.add_scalar('Validation/f1_score', avg_f1_score, epoch)
        

        # Save model and optimizer
        checkpoint = {
            'model_state_dict': model.state_dict(),
            'optimizer_state_dict': optimizer.state_dict()
        }
        torch.save(checkpoint, os.path.join(model_saving_folder, f'{epoch}.pth'))