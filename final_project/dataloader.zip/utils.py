import datetime

def convert_to_scientific(value:float, identifier:str="") -> str:
    """Conver a float value to the string of scientific notation
    """
    if value == None:
        return ""
    else:
        value = '{:.0e}'.format(value)
        if '-' in value:
            index = value.index('-')
        else:
            index = value.index('+')
        if value[index + 1] == '0':
            value = value[:index + 1] + value[index + 2:]
        
        if identifier != "":
            return '&{}{}'.format(identifier, value)
        else:
            return value
        
        
def get_timestamp() -> str:
    cur_time = datetime.datetime.utcnow()
    timestamp = "[%d-%02d-%02d-%02d%02d]" % (cur_time.year, 
                                            cur_time.month, 
                                            cur_time.day, 
                                            cur_time.hour, 
                                            cur_time.minute)
    return timestamp